python interpolate_manual.py start.xyz end.xyz
for i in {0..29}; do cat interpolate$i.xyz >> geometries.xyz ; done

