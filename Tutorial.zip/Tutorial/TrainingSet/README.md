Go to the folder "Initial" and open the provided jupyter notebook to see an example on how to generate your initial training set.

Go to the folder "AdaptiveSampling" and open the provided jupyter notebook to see an example on how to do adaptive sampling and append a training set.
