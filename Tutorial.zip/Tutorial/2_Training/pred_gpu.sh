#testing 
python $SCHNARC/run_schnarc.py pred ../DBs/initconds.db Train --cuda
