Open the provided jupyter notebook "GenerateInitialTrainingset.ipynb" to find out how to generate a trainnig set for SchNarc.
