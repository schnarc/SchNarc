#testing 
python $SCHNARC/run_schnarc.py pred initconds.db Train 

