#evaluation
#possible splits: train, validation, test, all
python $SCHNARC/run_schnarc.py eval schnet --split validation  --batch_size 10 ../Datasets/Fulvene.db Train --cuda

