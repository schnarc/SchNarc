#execute SchNarc
python $SCHNARC/schnarc_md.py pred ../../../DBs/Fulvene.db ../../../Models/Model1 >> NN.log 2>> NN.err

